const express = require('express');
const app = express();
// const Joi = require('joi')

const pool = require('./config/database');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/** 
 *  เริ่มทำข้อสอบได้ที่ใต้ข้อความนี้เลยครับ
 * !!! ไม่ต้องใส่ app.listen() ในไฟล์นี้นะครับ มันจะไป listen ที่ไฟล์ server.js เองครับ !!!
 * !!! ห้ามลบ module.exports = app; ออกนะครับ  ไม่งั้นระบบตรวจไม่ได้ครับ !!!
*/

// const blogSchema = Joi.object({
   
//     title : Joi.string().required(),
//     description : Joi.string().required()

// })


app.get('/todo', async function (req, res, next) {
   const start_date = req.query.start_date
   const end_date = req.query.end_date

   if (!(start_date || end_date)) {
    const [todo] = await pool.query(`
select *, DATE_FORMAT(due_date, "%Y-%m-%d") AS due_date
from todo
where due_date`)
    res.status(200).send(todo)
}

else{
    const[news2, feilds2] = await pool.query(`SELECT *, DATE_FORMAT(due_date, '%Y-%m-%d') AS due_date  FROM todo WHERE due_date  between ? and ? `, [start_date, end_date] )
    console.log(news2)
    res.status(200).send(news2)
}

});

app.post('/todo', async function (req, res, next){
    console.log(req.body)

    // try{
    //     await blogSchema.validateAsync(req.body,  { abortEarly: false })
    // }catch(err){
    //     return res.status(400).send()
    // }
    const title = req.body.title
    const description = req.body.description
    var due_date = req.body.due_date
    var order = 0

    if(title == ''){
        res.status(400).send({"message": "ต้องกรอก title"})
    }
    else if(description == ''){
        res.status(400).send({"message": "ต้องกรอก description"})
    }
    else if(due_date == ''){
        due_date = new Date()
    }

    const[rows, feilds] = await pool.query('SELECT max(todo.order) as mtodo FROM todo')
    console.log(rows[0].mtodo)
    order = rows[0].mtodo + 1
    console.log(order)
    console.log(due_date)
    try{
        const[news, feilds1] = await pool.query('INSERT INTO todo (title, description, due_date, todo.order) VALUES(?, ?, ?, ?)', [title, description, due_date, order])
        
        const[news2, feilds2] = await pool.query(`SELECT *, DATE_FORMAT(due_date, '%Y-%m-%d') AS due_date  FROM todo WHERE todo.order = ?`, [order])
        console.log(news2)

        res.status(201).send({"message" : `สร้าง ToDo '${title}' สำเร็จ`, "todo" : news2[0]})

    }catch(err){
        console.log(err)
    }

})


app.delete('/todo/:id', async function(req, res, next){
    const [title, fields1] = await pool.query('SELECT title FROM todo WHERE id = ?', [req.params.id])
    console.log(title[0])
    if(title == ''){
        res.status(404).send({message : "ไม่พบ ToDo ที่ต้องการลบ"})
    }
    try{
        const [rows, fields] = await pool.query('DELETE FROM todo WHERE id = ?', [req.params.id])
        res.status(200).send({message : `ลบ ToDo '${title[0].title}' สำเร็จ`})
    }catch(err){
        console.log(err)
    }
})


module.exports = app;
